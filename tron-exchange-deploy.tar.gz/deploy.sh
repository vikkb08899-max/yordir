#!/bin/bash

# Скрипт деплоя TRX Exchange на продакшн сервер
set -e

echo "🚀 Начинаем деплой TRX Exchange..."

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функция для логирования
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

# Проверяем наличие необходимых файлов
log "Проверяем конфигурацию..."

if [ ! -f "backend/.env" ]; then
    error "Файл backend/.env не найден! Создайте его с необходимыми переменными."
fi

if [ ! -f "package.json" ]; then
    error "Файл package.json не найден!"
fi

# Билдим фронтенд
log "Собираем фронтенд..."
npm install
npm run build

# Проверяем Docker
if ! command -v docker &> /dev/null; then
    error "Docker не установлен. Установите Docker и Docker Compose."
fi

if ! command -v docker-compose &> /dev/null; then
    error "Docker Compose не установлен."
fi

# Создаем необходимые директории
log "Создаем директории..."
mkdir -p logs
mkdir -p ssl

# Проверяем SSL сертификаты
if [ ! -f "ssl/cert.pem" ] || [ ! -f "ssl/key.pem" ]; then
    warn "SSL сертификаты не найдены в папке ssl/"
    warn "Создаем самоподписанные сертификаты для тестирования..."
    
    openssl req -x509 -newkey rsa:4096 -keyout ssl/key.pem -out ssl/cert.pem -days 365 -nodes \
        -subj "/C=US/ST=State/L=City/O=Organization/CN=localhost"
    
    warn "⚠️  Используются самоподписанные сертификаты!"
    warn "⚠️  Для продакшена получите реальные SSL сертификаты (Let's Encrypt)!"
fi

# Останавливаем старые контейнеры
log "Останавливаем старые контейнеры..."
docker-compose down --remove-orphans || true

# Удаляем старые образы
log "Очищаем старые образы..."
docker system prune -f || true

# Билдим и запускаем новые контейнеры
log "Собираем и запускаем новые контейнеры..."
docker-compose up --build -d

# Проверяем статус
log "Проверяем статус контейнеров..."
sleep 10

if docker-compose ps | grep -q "Up"; then
    log "✅ Деплой успешно завершен!"
    log "🌐 Приложение доступно по адресу: https://ваш_домен.com"
    log "📊 Логи: docker-compose logs -f"
    log "🔧 Управление: docker-compose [start|stop|restart]"
else
    error "❌ Контейнеры не запустились. Проверьте логи: docker-compose logs"
fi

# Показываем финальную информацию
echo ""
echo "=================================================="
echo "🎉 TRX Exchange успешно развернут!"
echo "=================================================="
echo "📍 URL: https://ваш_домен.com"
echo "🔧 Управление: docker-compose [start|stop|restart]"
echo "📊 Логи приложения: docker-compose logs -f app"
echo "🌐 Логи nginx: docker-compose logs -f nginx"
echo "📁 Логи приложения: ./logs/"
echo "==================================================" 